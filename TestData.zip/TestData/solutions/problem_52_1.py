class Solution:
    def solution_52_1(self, s, wordDict):
		dp = [False]*(len(s)+1)
        dp[0] = True
        
        for i in range(1, len(s)+1):
            for j in range(i):
                if dp[j] and s[j:i] in wordDict:
					dp[i] = True
                    break
                    
        return dp[-1]