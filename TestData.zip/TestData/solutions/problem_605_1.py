class Solution:
    def solution_605_1(self, arr: List[int], target: int) -> int:
        arr.sort()
		# the rest of the code here