class Solution:
    def solution_420_5(self, s: str) -> str:
        return s.lower()