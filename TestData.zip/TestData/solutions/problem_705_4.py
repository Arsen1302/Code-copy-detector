class Solution:
    def solution_705_4(self, n: int) -> bool:
        return n%2 == 0