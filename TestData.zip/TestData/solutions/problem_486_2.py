class Solution:
    def solution_486_2(self, A: str, B: str) -> bool:
    	return (A in B*2) and (len(A) == len(B))
		
		
- Junaid Mansuri
(LeetCode ID)@hotmail.com