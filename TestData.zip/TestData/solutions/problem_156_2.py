class Solution:
    def solution_156_2(self, n: int) -> int:
        return int(n**0.5)