class Solution:
    def solution_540_1(self, arr: List[int]) -> int:
        return (arr.index(max(arr)))