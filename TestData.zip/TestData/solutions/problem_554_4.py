class Solution:
    def solution_554_4(self, matrix: List[List[int]]) -> List[List[int]]:
        return zip(*matrix)